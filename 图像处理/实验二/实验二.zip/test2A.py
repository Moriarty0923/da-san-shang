import cv2
import matplotlib.pyplot as plt

img = cv2.imread("1.jpg", 1)
cv2.imshow("img", img)

print("图像分辨率为:", img.shape[1], "×", img.shape[0])                 # 读取图像分辨率
height = img.shape[0]
width = img.shape[1]
print("左上四分之一处点的像素值为:", img[int(height/4), int(width/4)])     # 左上1/4点的像素值

img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)                      # 转化为灰度图
plt.hist(img_gray.ravel(), 256)                                       # 绘制直方图
plt.show()

# img_gray_equalized = cv2.equalizeHist(img_gray)
# plt.hist(img_gray_equalized.ravel(), )
# plt.show()

cv2.imshow("img1", img_gray)
#cv2.imshow("img2", img_gray_equalized)
cv2.waitKey(0)