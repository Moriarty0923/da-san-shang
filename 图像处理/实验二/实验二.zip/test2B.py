import cv2
import math
import numpy as np


'''
灰度线性变化增强
a<0 and b=255: 图像的亮区域变暗，暗区域变亮
a>1: 增强图像的对比度,图像看起来更加清晰
a<1: 减小了图像的对比度, 图像看起来变暗
a=1且b≠0, 图像整体的灰度值上移或者下移, 也就是图像整体变亮或者变暗, 不会改变图像的对比度
a=-1, b=255, 图像翻转
'''
def gray_line_enhance(a, b, img):
    gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    new_img = np.ones((gray_img.shape[0], gray_img.shape[1]), dtype=np.uint8)
    for i in range(new_img.shape[0]):
        for j in range(new_img.shape[1]):
            new_img[i][j] = min(max(gray_img[i][j] * a + b, 0), 255)
    return new_img

"""
灰度分段变化增强
该函数将灰度值小于50的点，增大两倍
灰度值50-150的点，增大1.5倍
灰度值150以上的点，增大2倍
实现了灰度图线性分段增强的功能
"""
def gray_divided_line_enhance(img):
    gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    new_img = np.ones((gray_img.shape[0], gray_img.shape[1]), dtype=np.uint8)
    for i in range(gray_img.shape[0]):
        for j in range(gray_img.shape[1]):
                pix = gray_img[i][j]
                if pix < 50:
                    new_img[i][j] = min(255, 2 * pix)
                elif pix < 150:
                    new_img[i][j] = min(255, 1.5 * pix)
                elif pix < 255:
                    new_img[i][j] = min(255, 1.25 * pix)
                else:
                    new_img[i][j] = pix
    return new_img

"""
灰度图像指数变化
g(x,y) = b ^ c(f(x,y)-a)
通过函数的指数变化可以将图像的高亮度区域进行大幅扩展
测试时输入参数a = 10，b = 1.0255，c =2 
"""
def gray_index_enhance(a, b, c, img):
    gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    new_img = np.ones((gray_img.shape[0], gray_img.shape[1]), dtype=np.uint8)
    for i in range(gray_img.shape[0]):
        for j in range(gray_img.shape[1]):
            pix = gray_img[i][j]
            new_img[i][j] = min(255, b ** (max(c * pix - a, 0)))
    return new_img

"""
直方图变化增强
这里通过equalizeHist函数进行直方图平衡化
其实通过直方图均衡化就可以实现思考题中根据图片的特性（如明暗或者分布）来自动调整整个图片亮度
"""
def zhifangtu_enhance(img):
    (b, g, r) = cv2.split(img)
    bH = cv2.equalizeHist(b)
    gH = cv2.equalizeHist(g)
    rH = cv2.equalizeHist(r)
    result = cv2.merge((bH, gH, rH),)
    return result

"""
思考题：可否根据图片的特性（如明暗或者分布）来自动调整参数？
该函数是灰度图像的幂次变化
可以实时查看当前图像情况来改变 参数γ的大小
g(x,y) = f(x,y)^γ
"""
def manual_enhance(img):
    cv2.namedWindow('gray_img')
    cv2.createTrackbar('gama*100', 'gray_img', 0, 200, lambda x: x)
    gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    new_img = np.ones((gray_img.shape[0], gray_img.shape[1]), dtype=np.uint8)
    while True:
        gama = cv2.getTrackbarPos('gama*100', 'gray_img')
        for i in range(gray_img.shape[0]):
            for j in range(gray_img.shape[1]):
                pix = gray_img[i][j]
                new_img[i][j] = min(pix ** (gama/100), 255)
        cv2.imshow('gray_img', new_img)
        cv2.waitKey(10)

def auto_enhance(img):
    hsv_image = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    lightness = hsv_image[:, :, 2].mean()
    #如果画面的平均灰度值达到一定亮度，不再做改变
    if lightness > 130:
        return img
    max_percentile_pixel = np.percentile(img, 99)
    min_percentile_pixel = np.percentile(img, 1)
    # 去掉分位值区间之外的值
    img[img >= max_percentile_pixel] = max_percentile_pixel
    img[img <= min_percentile_pixel] = min_percentile_pixel

    # 将分位值区间拉伸到0到255，
    new_img = np.zeros(img.shape, img.dtype)
    cv2.normalize(img, new_img, 255 * 0.1, 255 * 0.9, cv2.NORM_MINMAX)
    return new_img




filename = "3.jpg"
img = cv2.imread(filename)
img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
cv2.imshow('origin', img)
# cv2.imshow('gray_image', img_gray)
# # cv2.imshow('line_enhance', gray_line_enhance(2, 10, img))
# # cv2.imshow("divided_line_enhance", gray_divided_line_enhance(img))
# # cv2.imshow("index_enhance", gray_index_enhance(10, 1.0255, 2, img))
# # cv2.imshow("zhifangtu_enhance", zhifangtu_enhance(img))
# cv2.imshow('a=2,b=10', gray_line_enhance(2, 10, img))
# cv2.imshow('a=1,b=100', gray_line_enhance(1, 100, img))
# cv2.imshow('a=-0.5,b=255', gray_line_enhance(-1, 255, img))
# cv2.imshow('a=0.5,b=80', gray_line_enhance(0.5, 80, img))
#manual_enhance(img)
cv2.imshow("auto", auto_enhance(img))
cv2.waitKey(0)
